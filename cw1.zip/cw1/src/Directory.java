import java.util.ArrayList;

public class Directory implements Component{

    //store the sub-directories and files
    private ArrayList<Component> children;
    private String name;

    //Constructor - create the sub directories list and set name
    public Directory(String name) {
        children = new ArrayList<Component>();
        this.name = name;
    }

    //get name - get this directory's name
    public String getName() {
        return name;
    }

    //set name - set the name of this directory
    public void setName(String name) {
        this.name = name;
    }

    //get size - get the total size of files in this directory
    public int getSize() {
        int size = 0;
        for(Component child: children) {
            size += child.getSize();
        }
        return size;
    }

    //get count - get the number of files in this directory
    public int getCount() {
        int count = 0;
        for(Component child: children) {
            count += child.getCount();
        }
        return count;
    }

    //add directory/file into this directory
    public void add(Component child) {
        children.add(child);
    }

    //remove directory/file from this directory
    public void remove(Component child) {
        children.remove(child);
    }

    //display - display the directory in predefined format
    public String display(String prefix) {
        String total = name + ": (count=" + getCount() + ", size=" + getSize() + ")";
        for(Component a: children) {
            total += "\n" + prefix + a.display(prefix).replaceAll("\n","\n"+prefix);
        }
        return total;
    }

    //search - search if this directory include the "name" file
    public Component search(String name) {
        for (Component a: children) {
            if(name == a.getName()) {
                if(a.search(name) == a){
                    return this;
                }else{
                    return null;
                }
            }else{
                if(a.search(name) == null){
                    continue;
                }else {
                    return a.search(name);
                }
            }
        }
        return null;
    }
}
