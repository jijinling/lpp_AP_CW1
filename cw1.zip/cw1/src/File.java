
public class File implements Component{
    private int size;
    private String name;

    //constructor - set the size and name of a new file
    public File(String name, int size) {
        this.name = name;
        this.size =size;
    }

    //get size - get the size of the file
    public int getSize() {
        return size;
    }

    //get name - get the name of the file
    public String getName() {
        return name;
    }

    //set name - change the name of the file
    public void setName(String name) {
        this.name = name;
    }

    //get count - the File class has fixed count 1
    public int getCount() {
        return 1;
    }

    //display - display the file information in the predefined format
    public String display(String prefix) {
        return name + " (" + size + ")";
    }

    //search - search the file name and return the related directory.
    public Component search(String name) {
        if (name == this.name){
            return this;
        }
        return null;
    }


}
